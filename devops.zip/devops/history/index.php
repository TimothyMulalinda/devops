<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History Data</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>History Data</h2>
        <br>
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#insertModal">Insert Data</button>

        <!-- Modal -->
        <div class="modal fade" id="insertModal" tabindex="-1" aria-labelledby="insertModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title" id="insertModalLabel">Insert New Data</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Form untuk memasukkan data baru -->
                        <form id="insertForm">
                            <div class="mb-3">
                                <label for="id_class" class="form-label">ID Class</label>
                                <input type="text" class="form-control" id="id_class" name="id_class" required>
                            </div>
                            <div class="mb-3">
                                <label for="id_attendance" class="form-label">ID Attendance</label>
                                <input type="text" class="form-control" id="id_attendance" name="id_attendance" required>
                            </div>
                            <div class="mb-3">
                                <label for="email_student" class="form-label">Email Student</label>
                                <input type="email" class="form-control" id="email_student" name="email_student" required>
                            </div>
                            <div class="mb-3">
                                <label for="name_subject" class="form-label">Name Subject</label>
                                <input type="text" class="form-control" id="name_subject" name="name_subject" required>
                            </div>
                            <div class="mb-3">
                                <label for="email_lecturer" class="form-label">Email Lecturer</label>
                                <input type="email" class="form-control" id="email_lecturer" name="email_lecturer" required>
                            </div>
                            <div class="mb-3">
                                <label for="distance" class="form-label">Distances</label>
                                <input type="text" class="form-control" id="distance" name="distance" required>
                            </div>
                            <div class="mb-3">
                                <label for="time_take_attendance" class="form-label">Time Take Attendance</label>
                                <input type="text" class="form-control" id="time_take_attendance" name="time_take_attendance" required>
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label">Status</label>
                                <input type="text" class="form-control" id="status" name="status" required>
                            </div>
                            <div class="mb-3">
                                <label for="note" class="form-label">Note</label>
                                <input type="text" class="form-control" id="note" name="note" required>
                            </div>
                            <div class="text-center">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-success" onclick="submitOperatorForm()">Insert</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th class="text-center">ID Class</th>    
                    <th class="text-center">ID Attendance</th>
                    <th class="text-center">Email Student</th>
                    <th class="text-center">Name Subject</th>
                    <th class="text-center">Email Lecturer</th>
                    <th class="text-center">Distances</th>
                    <th class="text-center">Time Take Attendance</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Note</th>
                    <th class="text-center">Created at</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $conn = mysqli_connect("localhost", "root", "12345", "db_unklab");
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT * FROM tbl_attendance_history";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                        <td>".$row["id_class"]."</td>
                        <td>".$row["id_attendance"]."</td>
                        <td>".$row["email_student"]."</td>
                        <td>".$row["name_subject"]."</td>
                        <td>".$row["email_lecturer"]."</td>
                        <td>".$row["distance"]."</td>
                        <td>".$row["time_take_attendance"]."</td>
                        <td>".$row["status"]."</td>
                        <td>".$row["note"]."</td>
                        <td>".$row["created_at"]."</td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No Data</td></tr>";
                }
                mysqli_close($conn);
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function submitOperatorForm() {
            var id_class = $("#id_class").val();
            var id_attendance = $("#id_attendance").val();
            var email_student = $("#email_student").val();
            var name_subject = $("#name_subject").val();
            var email_lecturer = $("#email_lecturer").val();
            var distance = $("#distance").val();
            var time_take_attendance = $("#time_take_attendance").val();
            var status = $("#status").val();
            var note = $("#note").val();

            if (id_class === "" || id_attendance === "" || email_student === "" || name_subject === "" || email_lecturer === "" || distance === "" || time_take_attendance === "" || status === "" || note === "") {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Please fill in all fields!',
                });
                return;
            }

            $.ajax({
                type: "POST",
                url: "insertHistory.php",
                data: {
                    id_class: id_class,
                    id_attendance: id_attendance,
                    email_student: email_student,
                    name_subject: name_subject,
                    email_lecturer: email_lecturer,
                    distance: distance,
                    time_take_attendance: time_take_attendance,
                    status: status,
                    note: note
                },

                success: function(response) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: 'Data inserted successfully!',
                    }).then((result) => {
                        if (result.isConfirmed) {
                            location.reload();
                        }
                    });
                },
                error: function(error) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong!',
                    });
                }
            });
        }
    </script>

</body>
</html>

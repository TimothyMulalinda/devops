<?php
$conn = mysqli_connect("localhost", "root", "12345", "db_unklab");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_class = $_POST["id_class"];
    $id_attendance = $_POST["id_attendance"];
    $email_student = $_POST["email_student"];
    $name_subject = $_POST["name_subject"];
    $email_lecturer = $_POST["email_lecturer"];
    $distance = $_POST["distance"];
    $time_take_attendance = $_POST["time_take_attendance"];
    $status = $_POST["status"];
    $note = $_POST["note"];

    $currentDateTime = date('Y-m-d H:i:s');

    $sqlInsert = "INSERT INTO tbl_attendance_history (id_class, id_attendance, email_student, name_subject, email_lecturer, distance, time_take_attendance, status, note, created_at) 
                    VALUES ('$id_class', '$id_attendance', '$email_student', '$name_subject', '$email_lecturer', '$distance', '$time_take_attendance', '$status', '$note', '$currentDateTime')";

    if (mysqli_query($conn, $sqlInsert)) {
        echo "Data berhasil ditambahkan.";
    } else {
        echo "Error: " . $sqlInsert . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<?php
$conn = mysqli_connect("localhost", "root", "12345", "db_unklab");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title_short = $_POST["title_short"];
    $date_attendance = $_POST["date_attendance"];
    $time_attendance = $_POST["tme_attendance"];
    $id_class = $_POST["id_class"];
    $name_subject = $_POST["name_subject"];
    $email_lecturer = $_POST["email_lecturer"];
    $name_lecturer = $_POST["name_lecturer"];
    $max_radius = $_POST["max_radius"];

    $sqlInsert = "INSERT INTO tbl_attendance_list (title_short, date_attendance, time_attendance, id_class, name_subject, email_lecturer, name_lecturer, max_radius) 
    VALUES ('$title_short', '$date_attendance', '$time_attendance', '$id_class', '$name_subject', '$email_lecturer', '$name_lecturer', '$max_radius')";

    if (mysqli_query($conn, $sqlInsert)) {
        echo "Data berhasil ditambahkan.";
    } else {
        echo "Error: " . $sqlInsert . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

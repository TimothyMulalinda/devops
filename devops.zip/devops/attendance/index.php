<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance List</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Attendance List</h2><br>

        <!-- Button trigger modal -->
        <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#insertModal">Insert Data</button>

        <!-- Modal -->
        <div class="modal fade" id="insertModal" tabindex="-1" aria-labelledby="insertModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title" id="insertModalLabel">Insert New Data</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Form untuk memasukkan data baru -->
                        <form id="insertForm">
                            <div class="mb-3">
                                <label for="title_short" class="form-label">Title Short</label>
                                <input type="text" class="form-control" id="title_short" name="title_short" required>
                            </div>
                            <div class="mb-3">
                                <label for="date_attendance" class="form-label">Date Attendance</label>
                                <input type="date" class="form-control" id="date_attendance" name="date_attendance" required>
                            </div>
                            <div class="mb-3">
                                <label for="time_attendance" class="form-label">Time Attendance</label>
                                <input type="time" class="form-control" id="time_attendance" name="time_attendance" required>
                            </div>
                            <div class="mb-3">
                                <label for="id_class" class="form-label">ID Class</label>
                                <input type="text" class="form-control" id="id_class" name="id_class" required>
                            </div>
                            <div class="mb-3">
                                <label for="name_subject" class="form-label">Name Subject</label>
                                <input type="text" class="form-control" id="name_subject" name="name_subject" required>
                            </div>
                            <div class="mb-3">
                                <label for="email_lecturer" class="form-label">Email Lecturer</label>
                                <input type="email" class="form-control" id="email_lecturer" name="email_lecturer" required>
                            </div>
                            <div class="mb-3">
                                <label for="name_lecturer" class="form-label">Name Lecturer</label>
                                <input type="text" class="form-control" id="name_lecturer" name="name_lecturer" required>
                            </div>
                            <div class="mb-3">
                                <label for="max_radius" class="form-label">Max Radius</label>
                                <input type="number" class="form-control" id="max_radius" name="max_radius" required>
                            </div>
                            <div class="text-center">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-success" onclick="submitOperatorForm()">Insert</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th class="text-center">ID Attendance</th>
                    <th class="text-center">Title Short</th>
                    <th class="text-center">Date Attendance</th>
                    <th class="text-center">Time Attendance</th>
                    <th class="text-center">ID Class</th>
                    <th class="text-center">Name Subject</th>
                    <th class="text-center">Email Lecturer</th>
                    <th class="text-center">Name Lecturer</th>
                    <th class="text-center">Max Radius</th>
                    <th class="text-center">Created at</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $conn = mysqli_connect("localhost", "root", "12345", "db_unklab");

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT * FROM tbl_attendance_list";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                        <td>".$row["id_attendance"]."</td>
                        <td>".$row["title_short"]."</td>
                        <td>".$row["date_attendance"]."</td>
                        <td>".$row["time_attendance"]."</td>
                        <td>".$row["id_class"]."</td>
                        <td>".$row["name_subject"]."</td>
                        <td>".$row["email_lecturer"]."</td>
                        <td>".$row["name_lecturer"]."</td>
                        <td>".$row["max_radius"]."</td>
                        <td>".$row["created_at"]."</td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No Data</td></tr>";
                }
                mysqli_close($conn);
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function submitOperatorForm() {
            var title_short = $("#title_short").val();
            var date_attendance = $("#date_attendance").val();
            var time_attendance = $("#time_attendance").val();
            var id_class = $("#id_class").val();
            var name_subject = $("#name_subject").val();
            var email_lecturer = $("#email_lecturer").val();
            var name_lecturer = $("#name_lecturer").val();
            var max_radius = $("#max_radius").val();

            if (title_short === "" || date_attendance === "" || time_attendance === "" ||
                id_class === "" || name_subject === "" || email_lecturer === "" ||
                name_lecturer === "" || max_radius === "") {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Please fill in all fields!',
                });
                return;
            }

            $.ajax({
                type: "POST",
                url: "insertAttendance.php",
                data: {
                    title_short: title_short,
                    date_attendance: date_attendance,
                    time_attendance: time_attendance,
                    id_class: id_class,
                    name_subject: name_subject,
                    email_lecturer: email_lecturer,
                    name_lecturer: name_lecturer,
                    max_radius: max_radius
                },

                success: function(response) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: 'Data inserted successfully!',
                    }).then((result) => {
                        if (result.isConfirmed) {
                            location.reload();
                        }
                    });
                },
                error: function(error) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong!',
                    });
                }
            });
        }
    </script>
</body>
</html>

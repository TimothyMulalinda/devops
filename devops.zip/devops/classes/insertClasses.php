<?php
$conn = mysqli_connect("localhost", "root", "12345", "db_unklab");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_lecturer = $_POST["email_lecturer"];
    $code_class = $_POST["code_class"];
    $name_subject = $_POST["name_subject"];
    $name_lecturer = $_POST["name_lecturer"];
    $faculty = $_POST["faculty"];
    $major = $_POST["major"];
    $sks = $_POST["sks"];
    $building_room = $_POST["building_room"];
    $jadwal_class_day_time = $_POST["date_range"] . " " . $_POST["time_range"];
    $daftar_email_student = $_POST["daftar_email_student"];
    $status_class = $_POST["status_class"];

    $sqlInsert = "INSERT INTO tbl_classes (email_lecturer, code_class, name_subject, name_lecturer, fakultas, prodi, sks, building_room, jadwal_class_day_time, daftar_email_student, status_class, created_at) 
                    VALUES ('$email_lecturer', '$code_class', '$name_subject', '$name_lecturer', '$faculty', '$major', '$sks', '$building_room', '$jadwal_class_day_time', '$daftar_email_student', '$status_class', NOW())";

    if (mysqli_query($conn, $sqlInsert)) {
        echo "Data berhasil ditambahkan.";
    } else {
        echo "Error: " . $sqlInsert . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

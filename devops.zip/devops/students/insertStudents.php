<?php
$conn = mysqli_connect("localhost", "root", "12345", "db_unklab");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $regNumber = $_POST["regNumber"];
    $nimNumber = $_POST["nimNumber"];
    $email = $_POST["email"];
    $fullName = $_POST["fullName"];

    $currentDateTime = date('Y-m-d H:i:s');

    $sqlInsert = "INSERT INTO tbl_students (reg_number, nim_number, email, fullname, created_at, updated_at) 
                  VALUES ('$regNumber', '$nimNumber', '$email', '$fullName', '$currentDateTime', '$currentDateTime')";

    if (mysqli_query($conn, $sqlInsert)) {
        echo "Data berhasil ditambahkan.";
    } else {
        echo "Error: " . $sqlInsert . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<?php
$conn = mysqli_connect("localhost", "root", "12345", "db_unklab");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nip = $_POST["nip"];  // Adjusted variable name
    $email = $_POST["email"];
    $fullname = $_POST["fullname"];
    $phone_number = $_POST["phone_number"];  // Adjusted variable name
    $role = $_POST["role"];

    $currentDateTime = date('Y-m-d H:i:s');

    $sqlInsert = "INSERT INTO tbl_operator (nip, email, fullname, phone_number, role, created_at, updated_at) 
                  VALUES ('$nip', '$email', '$fullname', '$phone_number', '$role', '$currentDateTime', '$currentDateTime')";

    if (mysqli_query($conn, $sqlInsert)) {
        echo "Data berhasil ditambahkan.";
    } else {
        echo "Error: " . $sqlInsert . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
